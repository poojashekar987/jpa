package com.cognizant.ormlearn.springdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmLearnRelationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnRelationApplication.class, args);
	}

}
